/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pack;

import java.sql.*;

/**
 *
 * @author Asmita
 */
public class DBCon {
    Connection con;
    public Connection getcon()
    {
        try
        {
            Class.forName("org.h2.Driver");
            con=DriverManager.getConnection("jdbc:h2:tcp://localhost/~/passrec","asmita","qwerty");
        }
        catch(Exception e)
        {
            e.printStackTrace();
        }
        return con;
    }
}
